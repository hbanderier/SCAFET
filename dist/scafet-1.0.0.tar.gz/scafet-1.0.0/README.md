# SCAFET
SCAlable Feature Extraction and Tracking
